npm init --yes = crea un package.json básico (breve descripcion del proyecto)
npm i express (facilita el código) ejs morgan (para ver registros/logs de peticiones que hacen usuarios al servidor)
